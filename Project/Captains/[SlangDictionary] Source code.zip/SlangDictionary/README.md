# SlangDictionary
Enterprise Architecture - Group Project

# Technologies Used
1. Spring

2. Hibernate JPA

3. Email

4. Rest

5. Spring Security

6. AOP

7. Messaging

8. Testing

9. Hibernate Performance

10. MySQL
