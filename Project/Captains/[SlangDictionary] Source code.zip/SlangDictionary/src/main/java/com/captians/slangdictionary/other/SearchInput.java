package com.captians.slangdictionary.other;

public class SearchInput {
    public String input;

    public String getInput() {
        return input;
    }
}
