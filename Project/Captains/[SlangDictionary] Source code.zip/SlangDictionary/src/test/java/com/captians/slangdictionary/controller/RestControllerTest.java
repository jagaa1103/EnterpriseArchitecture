package com.captians.slangdictionary.controller;

import static org.junit.jupiter.api.Assertions.*;

class RestControllerTest {

}